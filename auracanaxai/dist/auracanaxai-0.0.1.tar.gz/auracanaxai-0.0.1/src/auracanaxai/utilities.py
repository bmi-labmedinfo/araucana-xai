import random


def add_one(number):
    return number + 1


def add_random(number):
    return number + random.randint(0, 100)
