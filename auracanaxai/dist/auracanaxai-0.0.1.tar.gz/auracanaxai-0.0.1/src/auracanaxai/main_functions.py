from . import constants
from pandas import DataFrame
import numpy as np
import matplotlib.pyplot as plt
from sklearn import tree
from gower import gower_matrix
from imblearn.over_sampling import SMOTENC

def __find_neighbours(target: np.ndarray, data: np.ndarray, cat_list: list, n: int = constants.NEIGHBOURHOOD_SIZE):
    if target.ndim != data.ndim: raise TypeError("target and data must have the same number of dimensions!")
    # Gower distance matrix
    d_gow = gower_matrix(target, data, cat_features=cat_list)
    # Let's select the first k neighbours
    d2index = dict(zip(d_gow[0].tolist(), list(range(data.shape[0]))))
    my_index = [d2index[i] for i in np.sort(d_gow)[0][0:n].tolist()]
    # nk nearest neighbours in the training set according to gower distance
    local_training_set = data[my_index, :]
    return local_training_set


# oversampling

def __oversample(x_local, x_instance, y_local_pred, y_instance_pred, cat_list: list, seed: int = constants.SEED):
    smote_nc = SMOTENC(categorical_features=np.where(cat_list)[0].tolist(), random_state=seed, sampling_strategy='all')
    return smote_nc.fit_resample(np.concatenate((x_local, x_instance)),
                                 np.append(y_local_pred, y_instance_pred))


# classification tree

def __create_tree(X, y, X_features):
    clf_tree_0 = tree.DecisionTreeClassifier(random_state=constants.SEED)
    clf_tree_0.fit(DataFrame(X, columns=X_features), y)
    print('Acc', clf_tree_0.score(X, y))
    return clf_tree_0


def __plot_tree(classif_tree, feature_names, class_names):
    fig, ax = plt.subplots(figsize=(10, 10))
    tree.plot_tree(classif_tree, feature_names=feature_names, filled=True, class_names=class_names)
    plt.show()


def run(x_target, y_pred_target, data_train, feature_names, cat_list, predict_fun, y_label=['negative', 'positive']):
    local_train = __find_neighbours(target=x_target,
                                    data=data_train,
                                    cat_list=cat_list)
    y_local_train = predict_fun(local_train)
    X_res, y_res = __oversample(x_local=local_train,
                                x_instance=x_target,
                                y_local_pred=y_local_train,
                                y_instance_pred=y_pred_target,
                                cat_list=cat_list)
    xai_c = __create_tree(X_res, y_res, feature_names)
    __plot_tree(xai_c, feature_names, y_label)
    return xai_c