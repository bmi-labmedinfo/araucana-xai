SEED: int = 42
NFOLD: int = 5
NEIGHBOURHOOD_SIZE: int = 100
SPLIT: float = .75
