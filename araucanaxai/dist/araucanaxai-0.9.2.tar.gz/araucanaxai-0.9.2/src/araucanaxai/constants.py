SEED: int = 42
NFOLD: int = 5
NEIGHBOURHOOD_SIZE: float = .01
OVERSAMPLING: str = None
OVERSAMPLING_SIZE: int = 100
MAX_DEPTH: int = None
MIN_SAMPLES_LEAF: int = 1
SPLIT: float = .75
